# ROS Workspace

## Building the Project

To build the project, use the following command:

```sh
colcon build
```
