from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration

def generate_launch_description():
    # Launch arguments for customizing robot parameters
    max_speed_arg = DeclareLaunchArgument(
        'max_linear_speed',
        default_value='0.5',
        description='Maximum linear speed (m/s)'
    )
    
    max_angular_arg = DeclareLaunchArgument(
        'max_angular_speed',
        default_value='1.5',
        description='Maximum angular speed (rad/s)'
    )
    
    wheel_radius_arg = DeclareLaunchArgument(
        'wheel_radius',
        default_value='0.05',
        description='Wheel radius (m)'
    )
    
    wheel_separation_arg = DeclareLaunchArgument(
        'wheel_separation',
        default_value='0.3',
        description='Wheel separation (m)'
    )

    # Create a LaunchDescription with our nodes
    return LaunchDescription([
        # Arguments
        max_speed_arg,
        max_angular_arg,
        wheel_radius_arg,
        wheel_separation_arg,
        
        # Differential Drive Controller
        Node(
            package='diffdrive_controller',
            executable='diffdrive_controller',
            name='diffdrive_controller',
            output='screen',
            parameters=[{
                'max_linear_speed': LaunchConfiguration('max_linear_speed'),
                'max_angular_speed': LaunchConfiguration('max_angular_speed'),
                'wheel_radius': LaunchConfiguration('wheel_radius'),
                'wheel_separation': LaunchConfiguration('wheel_separation'),
                'acceleration_limit': 0.5,
                'deceleration_limit': 0.7,
                'angular_accel_limit': 2.0,
            }],
        ),
        
        # If you want to launch the teleop node as well
        # (usually you'd run this in a separate terminal)
        # Node(
        #     package='diffdrive_controller',
        #     executable='teleop_keyboard',
        #     name='teleop_keyboard',
        #     output='screen',
        # ),
    ])