from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    # Get the package share directory
    pkg_dir = get_package_share_directory('ball_tracker')
    
    # Declare parameters file argument
    params_file = os.path.join(pkg_dir, 'config', 'ball_tracker_params.yaml')
    
    # Create a launch argument for the mode
    mode_arg = DeclareLaunchArgument(
        'mode',
        default_value='track',
        description='Operation mode: track (normal) or tune (for parameter tuning)'
    )
    
    # Launch the ball tracker node
    ball_tracker_node = Node(
        package='ball_tracker',
        executable='ball_tracker',
        name='ball_tracker',
        output='screen',
        parameters=[params_file],
        # This remapping is useful if your camera topics have different names
        remappings=[
            ('/camera/color/image_raw', LaunchConfiguration('rgb_topic', default='/camera/color/image_raw')),
            ('/camera/depth/image_rect_raw', LaunchConfiguration('depth_topic', default='/camera/depth/image_rect_raw')),
        ],
    )
    
    # Create condition for the parameter tuning mode
    param_tuning_node = Node(
        package='ball_tracker',
        executable='parameter_tuning',
        name='parameter_tuning',
        output='screen',
        condition=LaunchConfiguration('mode', default='track').equals('tune'),
    )
    
    # Create the launch description
    return LaunchDescription([
        mode_arg,
        DeclareLaunchArgument(
            'rgb_topic',
            default_value='/camera/color/image_raw',
            description='Topic for RGB camera'
        ),
        DeclareLaunchArgument(
            'depth_topic',
            default_value='/camera/depth/image_rect_raw',
            description='Topic for depth camera'
        ),
        ball_tracker_node,
        param_tuning_node,
    ])