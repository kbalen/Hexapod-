#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import ColorRGBA
from cv_bridge import CvBridge
from rcl_interfaces.msg import ParameterDescriptor, ParameterType
from rcl_interfaces.srv import GetParameters, SetParameters
from rcl_interfaces.msg import Parameter, ParameterValue
import cv2
import numpy as np
import tkinter as tk
from tkinter import ttk
import threading
import time

class ParameterTuningNode(Node):
    def __init__(self):
        super().__init__('parameter_tuning')
        
        # Parameters with descriptions
        self.declare_parameter('h_min', 0, 
                              ParameterDescriptor(
                                  type=ParameterType.PARAMETER_INTEGER,
                                  description='Minimum H value for ball color'))
        self.declare_parameter('h_max', 20, 
                              ParameterDescriptor(
                                  type=ParameterType.PARAMETER_INTEGER,
                                  description='Maximum H value for ball color'))
        self.declare_parameter('s_min', 100,
                              ParameterDescriptor(
                                  type=ParameterType.PARAMETER_INTEGER,
                                  description='Minimum S value for ball color'))
        self.declare_parameter('s_max', 255,
                              ParameterDescriptor(
                                  type=ParameterType.PARAMETER_INTEGER,
                                  description='Maximum S value for ball color'))
        self.declare_parameter('v_min', 100,
                              ParameterDescriptor(
                                  type=ParameterType.PARAMETER_INTEGER,
                                  description='Minimum V value for ball color'))
        self.declare_parameter('v_max', 255,
                              ParameterDescriptor(
                                  type=ParameterType.PARAMETER_INTEGER,
                                  description='Maximum V value for ball color'))
        self.declare_parameter('ball_min_radius', 10,
                              ParameterDescriptor(
                                  type=ParameterType.PARAMETER_INTEGER,
                                  description='Minimum ball radius in pixels'))
        
        # CV Bridge for image conversion
        self.bridge = CvBridge()
        
        # Subscribe to RGB image
        self.image_sub = self.create_subscription(
            Image,
            '/camera/color/image_raw',
            self.image_callback,
            10)
        
        # Publishers for debug images
        self.mask_pub = self.create_publisher(
            Image,
            '/ball_tracker/debug/mask',
            10)
        self.result_pub = self.create_publisher(
            Image,
            '/ball_tracker/debug/result',
            10)
        
        # Client to set parameters on the tracker node
        self.param_client = self.create_client(SetParameters, '/ball_tracker/set_parameters')
        
        # Latest image
        self.latest_image = None
        
        # Create GUI in a separate thread
        self.gui_thread = threading.Thread(target=self.create_gui)
        self.gui_thread.daemon = True
        self.gui_thread.start()
        
        self.get_logger().info('Parameter tuning node started')
    
    def image_callback(self, msg):
        """Store the latest image and process for visualization"""
        try:
            self.latest_image = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
            self.process_image()
        except Exception as e:
            self.get_logger().error(f'Error converting image: {e}')
    
    def process_image(self):
        """Process the image with current parameters for visualization"""
        if self.latest_image is None:
            return
        
        # Get current parameters
        h_min = self.get_parameter('h_min').value
        h_max = self.get_parameter('h_max').value
        s_min = self.get_parameter('s_min').value
        s_max = self.get_parameter('s_max').value
        v_min = self.get_parameter('v_min').value
        v_max = self.get_parameter('v_max').value
        ball_min_radius = self.get_parameter('ball_min_radius').value
        
        # Convert to HSV
        hsv = cv2.cvtColor(self.latest_image, cv2.COLOR_BGR2HSV)
        
        # Create mask
        lower_bound = np.array([h_min, s_min, v_min])
        upper_bound = np.array([h_max, s_max, v_max])
        mask = cv2.inRange(hsv, lower_bound, upper_bound)
        
        # Clean up mask
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.erode(mask, kernel, iterations=1)
        mask = cv2.dilate(mask, kernel, iterations=2)
        
        # Find contours
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # Copy original image for drawing
        result = self.latest_image.copy()
        
        # Find the largest contour
        if contours:
            largest_contour = max(contours, key=cv2.contourArea)
            ((x, y), radius) = cv2.minEnclosingCircle(largest_contour)
            
            # Draw circle if radius is large enough
            if radius > ball_min_radius:
                cv2.circle(result, (int(x), int(y)), int(radius), (0, 255, 0), 2)
                cv2.circle(result, (int(x), int(y)), 5, (0, 0, 255), -1)
                cv2.putText(result, f"r={int(radius)}", (int(x) + 10, int(y) + 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
        
        # Convert mask to color image for visualization
        mask_color = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)
        
        # Publish debug images
        try:
            self.mask_pub.publish(self.bridge.cv2_to_imgmsg(mask_color, 'bgr8'))
            self.result_pub.publish(self.bridge.cv2_to_imgmsg(result, 'bgr8'))
        except Exception as e:
            self.get_logger().error(f'Error publishing debug images: {e}')
    
    def create_gui(self):
        """Create a Tkinter GUI for parameter tuning"""
        root = tk.Tk()
        root.title("Ball Tracker Parameter Tuning")
        
        # Create main frame
        main_frame = ttk.Frame(root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Create HSV sliders
        ttk.Label(main_frame, text="HSV Color Thresholds").grid(row=0, column=0, columnspan=2, pady=5)
        
        # H min/max
        ttk.Label(main_frame, text="H min").grid(row=1, column=0, sticky=tk.W)
        h_min_var = tk.IntVar(value=self.get_parameter('h_min').value)
        h_min_slider = ttk.Scale(main_frame, from_=0, to=179, variable=h_min_var, orient=tk.HORIZONTAL, length=200)
        h_min_slider.grid(row=1, column=1, sticky=(tk.W, tk.E))
        h_min_slider.bind("<ButtonRelease-1>", lambda e: self.update_parameter('h_min', h_min_var.get()))
        
        ttk.Label(main_frame, text="H max").grid(row=2, column=0, sticky=tk.W)
        h_max_var = tk.IntVar(value=self.get_parameter('h_max').value)
        h_max_slider = ttk.Scale(main_frame, from_=0, to=179, variable=h_max_var, orient=tk.HORIZONTAL, length=200)
        h_max_slider.grid(row=2, column=1, sticky=(tk.W, tk.E))
        h_max_slider.bind("<ButtonRelease-1>", lambda e: self.update_parameter('h_max', h_max_var.get()))
        
        # S min/max
        ttk.Label(main_frame, text="S min").grid(row=3, column=0, sticky=tk.W)
        s_min_var = tk.IntVar(value=self.get_parameter('s_min').value)
        s_min_slider = ttk.Scale(main_frame, from_=0, to=255, variable=s_min_var, orient=tk.HORIZONTAL, length=200)
        s_min_slider.grid(row=3, column=1, sticky=(tk.W, tk.E))
        s_min_slider.bind("<ButtonRelease-1>", lambda e: self.update_parameter('s_min', s_min_var.get()))
        
        ttk.Label(main_frame, text="S max").grid(row=4, column=0, sticky=tk.W)
        s_max_var = tk.IntVar(value=self.get_parameter('s_max').value)
        s_max_slider = ttk.Scale(main_frame, from_=0, to=255, variable=s_max_var, orient=tk.HORIZONTAL, length=200)
        s_max_slider.grid(row=4, column=1, sticky=(tk.W, tk.E))
        s_max_slider.bind("<ButtonRelease-1>", lambda e: self.update_parameter('s_max', s_max_var.get()))
        
        # V min/max
        ttk.Label(main_frame, text="V min").grid(row=5, column=0, sticky=tk.W)
        v_min_var = tk.IntVar(value=self.get_parameter('v_min').value)
        v_min_slider = ttk.Scale(main_frame, from_=0, to=255, variable=v_min_var, orient=tk.HORIZONTAL, length=200)
        v_min_slider.grid(row=5, column=1, sticky=(tk.W, tk.E))
        v_min_slider.bind("<ButtonRelease-1>", lambda e: self.update_parameter('v_min', v_min_var.get()))
        
        ttk.Label(main_frame, text="V max").grid(row=6, column=0, sticky=tk.W)
        v_max_var = tk.IntVar(value=self.get_parameter('v_max').value)
        v_max_slider = ttk.Scale(main_frame, from_=0, to=255, variable=v_max_var, orient=tk.HORIZONTAL, length=200)
        v_max_slider.grid(row=6, column=1, sticky=(tk.W, tk.E))
        v_max_slider.bind("<ButtonRelease-1>", lambda e: self.update_parameter('v_max', v_max_var.get()))
        
        # Ball min radius
        ttk.Label(main_frame, text="Min Radius").grid(row=7, column=0, sticky=tk.W)
        radius_var = tk.IntVar(value=self.get_parameter('ball_min_radius').value)
        radius_slider = ttk.Scale(main_frame, from_=1, to=50, variable=radius_var, orient=tk.HORIZONTAL, length=200)
        radius_slider.grid(row=7, column=1, sticky=(tk.W, tk.E))
        radius_slider.bind("<ButtonRelease-1>", lambda e: self.update_parameter('ball_min_radius', radius_var.get()))
        
        # Apply to ball tracker button
        ttk.Button(main_frame, text="Apply to Ball Tracker", command=self.apply_to_tracker).grid(row=8, column=0, columnspan=2, pady=10)
        
        # Status label
        self.status_var = tk.StringVar(value="Ready")
        ttk.Label(main_frame, textvariable=self.status_var).grid(row=9, column=0, columnspan=2)
        
        # Configure resizing
        root.columnconfigure(0, weight=1)
        root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        
        # Main loop
        while rclpy.ok():
            root.update()
            time.sleep(0.01)
    
    def update_parameter(self, name, value):
        """Update a parameter in this node"""
        self.set_parameters([rclpy.parameter.Parameter(name, value=value)])
        self.status_var.set(f"Updated {name} to {value}")
        self.process_image()
    
    def apply_to_tracker(self):
        """Apply current parameters to the ball tracker node"""
        if not self.param_client.service_is_ready():
            self.status_var.set("Ball tracker service not available")
            return
        
        # Get current parameters
        h_min = self.get_parameter('h_min').value
        h_max = self.get_parameter('h_max').value
        s_min = self.get_parameter('s_min').value
        s_max = self.get_parameter('s_max').value
        v_min = self.get_parameter('v_min').value
        v_max = self.get_parameter('v_max').value
        ball_min_radius = self.get_parameter('ball_min_radius').value
        
        # Create parameters
        parameters = [
            Parameter(name='ball_color_hsv_lower', value=ParameterValue(
                type=ParameterType.PARAMETER_INTEGER_ARRAY,
                integer_array_value=[h_min, s_min, v_min])),
            Parameter(name='ball_color_hsv_upper', value=ParameterValue(
                type=ParameterType.PARAMETER_INTEGER_ARRAY,
                integer_array_value=[h_max, s_max, v_max])),
            Parameter(name='ball_min_radius', value=ParameterValue(
                type=ParameterType.PARAMETER_INTEGER,
                integer_value=ball_min_radius))
        ]
        
        # Send request
        future = self.param_client.call_async(SetParameters.Request(parameters=parameters))
        
        def callback(future):
            try:
                response = future.result()
                if all(result.successful for result in response.results):
                    self.status_var.set("Parameters applied successfully")
                else:
                    self.status_var.set("Failed to apply some parameters")
            except Exception as e:
                self.status_var.set(f"Error: {str(e)}")
        
        future.add_done_callback(callback)


def main(args=None):
    rclpy.init(args=args)
    
    node = ParameterTuningNode()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()