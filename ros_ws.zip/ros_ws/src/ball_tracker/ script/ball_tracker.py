#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image, PointCloud2
from geometry_msgs.msg import Twist, Point
from nav_msgs.msg import Odometry
from std_msgs.msg import Float32, ColorRGBA
from visualization_msgs.msg import Marker
from cv_bridge import CvBridge
import cv2
import numpy as np
import math
import tf2_ros
from tf2_geometry_msgs import do_transform_point
import message_filters
from collections import deque
import time

class BallTracker(Node):
    def __init__(self):
        super().__init__('ball_tracker')
        
        # Parameters (can be made configurable via ROS2 params)
        self.ball_color_lower = np.array([0, 100, 100])  # HSV lower bounds (for orange ball)
        self.ball_color_upper = np.array([20, 255, 255])  # HSV upper bounds
        self.ball_min_radius = 10  # minimum radius in pixels to consider
        self.max_tracking_distance = 5.0  # maximum distance to track ball (meters)
        self.history_size = 10  # number of positions to keep for velocity estimation
        self.max_robot_speed = 1.0  # max speed in m/s (adjust to your robot's capabilities)
        
        # Initialize bridge for image conversion
        self.bridge = CvBridge()
        
        # Position and velocity history
        self.ball_positions = deque(maxlen=self.history_size)
        self.ball_timestamps = deque(maxlen=self.history_size)
        
        # Robot state
        self.robot_x = 0.0
        self.robot_y = 0.0
        self.robot_orientation = 0.0
        
        # TF2 listener
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)
        
        # Synchronize depth and color image (if using synchronized topics)
        # self.rgb_sub = message_filters.Subscriber(self, Image, '/camera/color/image_raw')
        # self.depth_sub = message_filters.Subscriber(self, Image, '/camera/depth/image_rect_raw')
        # ts = message_filters.ApproximateTimeSynchronizer([self.rgb_sub, self.depth_sub], 10, 0.1)
        # ts.registerCallback(self.image_callback)
        
        # If topics are published separately, use separate subscribers
        self.rgb_sub = self.create_subscription(
            Image, 
            '/camera/color/image_raw', 
            self.rgb_callback, 
            10)
            
        self.depth_sub = self.create_subscription(
            Image, 
            '/camera/depth/image_rect_raw', 
            self.depth_callback, 
            10)
        
        # RGB and depth images
        self.latest_rgb = None
        self.latest_depth = None
        self.latest_rgb_time = None
        self.latest_depth_time = None
        
        # Subscriber for odometry
        self.odom_sub = self.create_subscription(
            Odometry, 
            'odom', 
            self.odom_callback, 
            10)
        
        # Publisher for robot commands
        self.cmd_vel_pub = self.create_publisher(Twist, 'cmd_vel', 10)
        
        # Publisher for visualization
        self.marker_pub = self.create_publisher(Marker, 'ball_marker', 10)
        
        # Processing timer
        self.timer = self.create_timer(0.05, self.process_data)  # 20Hz processing
        
        self.get_logger().info('Ball Tracker initialized')
    
    def rgb_callback(self, msg):
        """Process RGB image"""
        self.latest_rgb = msg
        self.latest_rgb_time = self.get_clock().now().to_msg()
    
    def depth_callback(self, msg):
        """Process Depth image"""
        self.latest_depth = msg
        self.latest_depth_time = self.get_clock().now().to_msg()
    
    def odom_callback(self, msg):
        """Process odometry data"""
        self.robot_x = msg.pose.pose.position.x
        self.robot_y = msg.pose.pose.position.y
        
        # Extract yaw from quaternion
        x = msg.pose.pose.orientation.x
        y = msg.pose.pose.orientation.y
        z = msg.pose.pose.orientation.z
        w = msg.pose.pose.orientation.w
        
        # Convert quaternion to yaw
        siny_cosp = 2.0 * (w * z + x * y)
        cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
        self.robot_orientation = math.atan2(siny_cosp, cosy_cosp)
    
    def process_data(self):
        """Main processing function to detect ball and command robot"""
        if self.latest_rgb is None or self.latest_depth is None:
            return
        
        # Convert ROS Image messages to OpenCV format
        try:
            cv_rgb = self.bridge.imgmsg_to_cv2(self.latest_rgb, 'bgr8')
            cv_depth = self.bridge.imgmsg_to_cv2(self.latest_depth, '32FC1')
        except Exception as e:
            self.get_logger().error(f'Failed to convert image: {e}')
            return
        
        # Detect ball in RGB image
        ball_detected, ball_x, ball_y, ball_radius = self.detect_ball(cv_rgb)
        
        if ball_detected:
            # Get 3D position from depth data
            depth_value = cv_depth[ball_y, ball_x]
            
            # Check if depth value is valid (not NaN or Inf)
            if math.isnan(depth_value) or math.isinf(depth_value):
                self.get_logger().warning('Invalid depth value at ball position')
                return
            
            # Convert pixel coordinates to 3D point
            ball_position = self.pixel_to_3d(ball_x, ball_y, depth_value)
            
            # Store position with timestamp for velocity estimation
            self.ball_positions.append((ball_position.x, ball_position.y, ball_position.z))
            self.ball_timestamps.append(time.time())
            
            # Publish ball marker for visualization
            self.publish_ball_marker(ball_position)
            
            # Estimate velocity if we have enough history
            if len(self.ball_positions) >= 3:
                ball_velocity = self.estimate_velocity()
                
                # Calculate interception point
                intercept_point = self.calculate_interception(ball_position, ball_velocity)
                
                # Move robot to intercept
                self.move_to_intercept(intercept_point)
            elif len(self.ball_positions) >= 1:
                # Just move toward the ball if we don't have velocity yet
                self.move_to_position(ball_position)
        else:
            # If ball not detected, stop or search
            self.search_for_ball()
    
    def detect_ball(self, rgb_image):
        """Detect ball in RGB image using color thresholding"""
        # Convert to HSV color space
        hsv = cv2.cvtColor(rgb_image, cv2.COLOR_BGR2HSV)
        
        # Create mask for ball color
        mask = cv2.inRange(hsv, self.ball_color_lower, self.ball_color_upper)
        
        # Apply morphological operations to clean up the mask
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.erode(mask, kernel, iterations=1)
        mask = cv2.dilate(mask, kernel, iterations=2)
        
        # Find contours
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # Find the largest contour
        if contours:
            largest_contour = max(contours, key=cv2.contourArea)
            ((x, y), radius) = cv2.minEnclosingCircle(largest_contour)
            
            # Check if the radius is reasonable
            if radius > self.ball_min_radius:
                return True, int(x), int(y), radius
        
        return False, 0, 0, 0
    
    def pixel_to_3d(self, pixel_x, pixel_y, depth):
        """Convert pixel coordinates and depth to 3D point in camera frame"""
        # Get camera intrinsics (these should be obtained from camera_info topic)
        # For this example, using typical values
        fx = 525.0  # focal length x
        fy = 525.0  # focal length y
        cx = 320.0  # optical center x
        cy = 240.0  # optical center y
        
        # Convert from pixels to meters in camera frame
        x = (pixel_x - cx) * depth / fx
        y = (pixel_y - cy) * depth / fy
        z = depth
        
        # Create Point message
        point = Point()
        point.x = z  # Depth camera convention: z forward, x right, y down
        point.y = -x
        point.z = -y
        
        # TODO: Transform point from camera frame to robot base frame
        # This requires the tf transform from camera to base
        try:
            transform = self.tf_buffer.lookup_transform(
                'base_link',
                'camera_link',
                rclpy.time.Time())
            
            point_transformed = do_transform_point(point, transform)
            return point_transformed
        except Exception as e:
            self.get_logger().warning(f'Transform failed: {e}')
            # Return untransformed point if transform fails
            return point
    
    def estimate_velocity(self):
        """Estimate ball velocity from position history"""
        if len(self.ball_positions) < 2:
            return (0.0, 0.0, 0.0)
        
        # Get last two positions and timestamps
        pos1 = self.ball_positions[-2]
        pos2 = self.ball_positions[-1]
        t1 = self.ball_timestamps[-2]
        t2 = self.ball_timestamps[-1]
        
        # Calculate velocity components
        dt = t2 - t1
        if dt <= 0.0:
            return (0.0, 0.0, 0.0)
        
        vx = (pos2[0] - pos1[0]) / dt
        vy = (pos2[1] - pos1[1]) / dt
        vz = (pos2[2] - pos1[2]) / dt
        
        return (vx, vy, vz)
    
    def calculate_interception(self, ball_position, ball_velocity):
        """Calculate the optimal interception point"""
        # Simple linear extrapolation for now
        # For better results, implement a physics-based model with gravity
        
        # Current ball position
        bx, by, bz = ball_position.x, ball_position.y, ball_position.z
        
        # Ball velocity
        vx, vy, vz = ball_velocity
        
        # Robot position
        rx, ry = self.robot_x, self.robot_y
        
        # Time horizon for prediction (adjust based on application)
        t_horizon = 2.0  # seconds
        
        # Simple iterative solution
        best_time = 0.0
        min_distance = float('inf')
        
        for t in np.linspace(0.1, t_horizon, 20):
            # Predicted ball position at time t
            predicted_bx = bx + vx * t
            predicted_by = by + vy * t
            
            # Distance robot would need to travel
            distance = math.sqrt((predicted_bx - rx)**2 + (predicted_by - ry)**2)
            
            # Time robot would need at max speed
            robot_time = distance / self.max_robot_speed
            
            # Difference between ball arrival time and robot arrival time
            time_diff = abs(t - robot_time)
            
            if time_diff < min_distance:
                min_distance = time_diff
                best_time = t
        
        # Calculate interception point
        intercept_x = bx + vx * best_time
        intercept_y = by + vy * best_time
        intercept_z = bz + vz * best_time
        
        # Create and return point
        intercept_point = Point()
        intercept_point.x = intercept_x
        intercept_point.y = intercept_y
        intercept_point.z = intercept_z
        
        return intercept_point
    
    def move_to_intercept(self, target_point):
        """Move robot to intercept the ball at the predicted point"""
        # Calculate direction to target
        dx = target_point.x - self.robot_x
        dy = target_point.y - self.robot_y
        distance = math.sqrt(dx*dx + dy*dy)
        
        # If we're close enough, stop
        if distance < 0.1:  # 10cm
            self.stop_robot()
            return
        
        # Calculate target heading
        target_heading = math.atan2(dy, dx)
        
        # Calculate heading error
        heading_error = self.normalize_angle(target_heading - self.robot_orientation)
        
        # Create twist message
        twist = Twist()
        
        # If we need to rotate significantly, do that first
        if abs(heading_error) > 0.3:  # ~17 degrees
            twist.angular.z = 3.0 * heading_error  # Proportional control
            twist.linear.x = 0.0
        else:
            # Move forward and turn simultaneously
            twist.linear.x = min(self.max_robot_speed, distance * 2.0)  # Proportional to distance
            twist.angular.z = 2.0 * heading_error  # Proportional control
        
        # Publish command
        self.cmd_vel_pub.publish(twist)
    
    def move_to_position(self, target_point):
        """Move directly to a position without prediction"""
        # Similar to move_to_intercept but without prediction
        # Calculate direction to target
        dx = target_point.x - self.robot_x
        dy = target_point.y - self.robot_y
        distance = math.sqrt(dx*dx + dy*dy)
        
        # Calculate target heading
        target_heading = math.atan2(dy, dx)
        
        # Calculate heading error
        heading_error = self.normalize_angle(target_heading - self.robot_orientation)
        
        # Create twist message
        twist = Twist()
        
        # If we need to rotate significantly, do that first
        if abs(heading_error) > 0.3:  # ~17 degrees
            twist.angular.z = 3.0 * heading_error  # Proportional control
            twist.linear.x = 0.0
        else:
            # Move forward and turn simultaneously
            twist.linear.x = min(self.max_robot_speed, distance * 2.0)  # Proportional to distance
            twist.angular.z = 2.0 * heading_error  # Proportional control
        
        # Publish command
        self.cmd_vel_pub.publish(twist)
    
    def search_for_ball(self):
        """Search for the ball by rotating slowly"""
        twist = Twist()
        twist.angular.z = 0.5  # Rotate slowly to search
        self.cmd_vel_pub.publish(twist)
    
    def stop_robot(self):
        """Stop the robot"""
        twist = Twist()
        twist.linear.x = 0.0
        twist.angular.z = 0.0
        self.cmd_vel_pub.publish(twist)
    
    def normalize_angle(self, angle):
        """Normalize angle to [-pi, pi]"""
        while angle > math.pi:
            angle -= 2.0 * math.pi
        while angle < -math.pi:
            angle += 2.0 * math.pi
        return angle
    
    def publish_ball_marker(self, ball_position):
        """Publish visualization marker for the ball"""
        marker = Marker()
        marker.header.frame_id = "map"  # Or whatever frame you're using
        marker.header.stamp = self.get_clock().now().to_msg()
        marker.ns = "ball"
        marker.id = 0
        marker.type = Marker.SPHERE
        marker.action = Marker.ADD
        
        marker.pose.position.x = ball_position.x
        marker.pose.position.y = ball_position.y
        marker.pose.position.z = ball_position.z
        marker.pose.orientation.w = 1.0
        
        marker.scale.x = 0.2  # Ball diameter (adjust to your ball size)
        marker.scale.y = 0.2
        marker.scale.z = 0.2
        
        marker.color.r = 1.0
        marker.color.g = 0.5
        marker.color.b = 0.0
        marker.color.a = 1.0
        
        self.marker_pub.publish(marker)


def main(args=None):
    rclpy.init(args=args)
    
    node = BallTracker()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        # Stop the robot before exiting
        node.stop_robot()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()