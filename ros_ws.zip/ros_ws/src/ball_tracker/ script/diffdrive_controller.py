#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan
from tf2_ros import TransformBroadcaster
from geometry_msgs.msg import TransformStamped
import math
import numpy as np
from threading import Lock
class PIDController:
    def __init__(self, kp, ki, kd, output_min, output_max):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.output_min = output_min
        self.output_max = output_max
        self.previous_error = 0.0
        self.integral = 0.0
        
    def compute(self, setpoint, measured_value, dt):
        # Calculate error
        error = setpoint - measured_value
        
        # Calculate P term
        p_term = self.kp * error
        
        # Calculate I term
        self.integral += error * dt
        i_term = self.ki * self.integral
        
        # Calculate D term
        derivative = (error - self.previous_error) / dt
        d_term = self.kd * derivative
        
        # Store previous error
        self.previous_error = error
        
        # Calculate total output
        output = p_term + i_term + d_term
        
        # Apply limits
        output = max(min(output, self.output_max), self.output_min)
        
        return output
        
    def reset(self):
        self.previous_error = 0.0
        self.integral = 0.0

class DiffDriveController(Node):
    def __init__(self):
        self.linear_pid = PIDController(0.5, 0.1, 0.05, -self.max_linear_speed, self.max_linear_speed)
        self.angular_pid = PIDController(1.0, 0.01, 0.1, -self.max_angular_speed, self.max_angular_speed)    
        
        super().__init__('diffdrive_controller')
        
        # Robot parameters (adjust these for your specific robot)
        self.wheel_radius = 0.05  # meters
        self.wheel_separation = 0.3  # meters
        self.max_linear_speed = 0.5  # m/s
        self.max_angular_speed = 1.5  # rad/s
        self.acceleration_limit = 1.2  # m/s^2
        self.deceleration_limit = 1.5  # m/s^2
        self.angular_accel_limit = 4.0  # rad/s^2
        
        # Current state variables
        self.current_linear_speed = 0.0
        self.current_angular_speed = 0.0
        self.position_x = 0.0
        self.position_y = 0.0
        self.orientation_theta = 0.0
        self.obstacle_detected = False
        self.state_lock = Lock()
        
        # Publishers
        self.cmd_vel_pub = self.create_publisher(Twist, 'cmd_vel', 10)
        
        # Subscribers
        self.odom_sub = self.create_subscription(
            Odometry,
            'odom',
            self.odom_callback,
            10)
        
        self.scan_sub = self.create_subscription(
            LaserScan,
            'scan',
            self.scan_callback,
            10)
        
        # Transform broadcaster for tf
        self.tf_broadcaster = TransformBroadcaster(self)
        
        # Timer for the control loop
        self.control_timer = self.create_timer(0.01, self.control_loop)  # 20Hz control loop
        
        # Target velocities (set by external commands)
        self.target_linear_velocity = 0.0
        self.target_angular_velocity = 0.0
        
        self.get_logger().info('Differential Drive Controller initialized')
    
    def odom_callback(self, msg):
        """Process odometry data to update robot state"""
        with self.state_lock:
            self.position_x = msg.pose.pose.position.x
            self.position_y = msg.pose.pose.position.y
            
            # Extract orientation from quaternion (simplified)
            qx = msg.pose.pose.orientation.x
            qy = msg.pose.pose.orientation.y
            qz = msg.pose.pose.orientation.z
            qw = msg.pose.pose.orientation.w
            
            # Convert quaternion to yaw (theta)
            siny_cosp = 2.0 * (qw * qz + qx * qy)
            cosy_cosp = 1.0 - 2.0 * (qy * qy + qz * qz)
            self.orientation_theta = math.atan2(siny_cosp, cosy_cosp)
        
        # Broadcast transform
        self.broadcast_transform(msg.header.stamp)
    
    def scan_callback(self, msg):
        """Process laser scan data for obstacle detection"""
        # Simple obstacle detection logic - check if any scan points are too close
        min_distance_threshold = 0.3  # meters
        
        # Filter out invalid readings (zeros or inf)
        valid_ranges = [r for r in msg.ranges if r > 0.0 and not math.isinf(r)]
        
        if valid_ranges and min(valid_ranges) < min_distance_threshold:
            self.obstacle_detected = True
            self.get_logger().warn(f'Obstacle detected at {min(valid_ranges):.2f}m!')
        else:
            self.obstacle_detected = False
    
    def broadcast_transform(self, timestamp):
        """Broadcast the transform from odom to base_link"""
        t = TransformStamped()
        
        t.header.stamp = timestamp
        t.header.frame_id = 'odom'
        t.child_frame_id = 'base_link'
        
        t.transform.translation.x = self.position_x
        t.transform.translation.y = self.position_y
        t.transform.translation.z = 0.0
        
        # Convert theta to quaternion (simplified)
        cy = math.cos(self.orientation_theta * 0.5)
        sy = math.sin(self.orientation_theta * 0.5)
        t.transform.rotation.x = 0.0
        t.transform.rotation.y = 0.0
        t.transform.rotation.z = sy
        t.transform.rotation.w = cy
        
        self.tf_broadcaster.sendTransform(t)
    
    def set_velocity(self, linear, angular):
        """Set target velocities for the robot"""
        self.target_linear_velocity = max(min(linear, self.max_linear_speed), -self.max_linear_speed)
        self.target_angular_velocity = max(min(angular, self.max_angular_speed), -self.max_angular_speed)
    
    def control_loop(self):
        """Main control loop to manage velocity transitions and obstacle avoidance"""
        dt = 0.01  # Control loop period
        
        # Don't move if obstacle detected
        if self.obstacle_detected:
            target_linear = 0.0
            # Turn to avoid the obstacle
            target_angular = 0.5  # Turn away from obstacle
        else:
            target_linear = self.target_linear_velocity
            target_angular = self.target_angular_velocity
        
        # Apply acceleration limits for smooth motion
        linear_speed_diff = target_linear - self.current_linear_speed
        if linear_speed_diff > 0:
            # Accelerating
            max_change = self.acceleration_limit * dt
            linear_speed_change = min(linear_speed_diff, max_change)
        else:
            # Decelerating
            max_change = self.deceleration_limit * dt
            linear_speed_change = max(linear_speed_diff, -max_change)
        
        # Apply angular acceleration limits
        angular_speed_diff = target_angular - self.current_angular_speed
        max_angular_change = self.angular_accel_limit * dt
        angular_speed_change = max(min(angular_speed_diff, max_angular_change), -max_angular_change)
        
        # Update current speeds
        self.current_linear_speed += linear_speed_change
        self.current_angular_speed += angular_speed_change
        
        # Create and publish Twist message
        twist = Twist()
        twist.linear.x = float(self.current_linear_speed)
        twist.angular.z = float(self.current_angular_speed)
        self.cmd_vel_pub.publish(twist)
        
        # Debug output occasionally
        if self.get_clock().now().nanoseconds % 100000000 < 5000000:  # Roughly every second
            self.get_logger().debug(
                f'Velocity: linear={self.current_linear_speed:.2f}, angular={self.current_angular_speed:.2f}'
            )

    def stop(self):
        """Emergency stop function"""
        self.set_velocity(0.0, 0.0)
        
        # Force immediate stop by publishing zero velocity
        twist = Twist()
        twist.linear.x = 0.0
        twist.angular.z = 0.0
        self.cmd_vel_pub.publish(twist)
        self.get_logger().info('Emergency stop activated')


def main(args=None):
    rclpy.init(args=args)
    
    controller = DiffDriveController()
    
    try:
        rclpy.spin(controller)
    except KeyboardInterrupt:
        pass
    finally:
        # Ensure the robot stops when the node is terminated
        controller.stop()
        controller.destroy_node()
        rclpy.shutdown()
def plan_trajectory(self, target_x, target_y, target_theta):
    """
    Generates a smooth trajectory to a target pose
    """
    # Calculate distance and angle to target
    dx = target_x - self.position_x
    dy = target_y - self.position_y
    distance = math.sqrt(dx*dx + dy*dy)
    
    # Target heading
    target_heading = math.atan2(dy, dx)
    
    # Heading error
    heading_error = self.normalize_angle(target_heading - self.orientation_theta)
    
    # Time to reach target at max speed (with buffer)
    time_to_target = distance / (self.max_linear_speed * 0.8)
    
    # Generate velocity profile (trapezoidal)
    accel_time = self.max_linear_speed / self.acceleration_limit
    decel_time = self.max_linear_speed / self.deceleration_limit
    
    # If we need to mainly rotate
    if abs(heading_error) > 0.4:  # ~23 degrees
        # First rotate in place
        return 0.0, self.angular_accel_limit * (1.0 if heading_error > 0 else -1.0)
    
    # Otherwise move and turn simultaneously
    linear_vel = min(distance * 0.5, self.max_linear_speed)
    angular_vel = heading_error * 2.0  # Proportional control for heading
    
    return linear_vel, angular_vel

def normalize_angle(self, angle):
    """Normalize angle to [-pi, pi]"""
    while angle > math.pi:
        angle -= 2.0 * math.pi
    while angle < -math.pi:
        angle += 2.0 * math.pi
    return angle

if __name__ == '__main__':
    main()