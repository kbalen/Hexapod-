import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from launch.substitutions import Command
from launch.substitutions import PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():
    package_name = "hexa"
    world_file = "empty.world"  # Change if you have a custom world
    gazebo_pkg = "gazebo_ros"
    
    # Paths
    pkg_share = get_package_share_directory(package_name)
    gazebo_launch_file = os.path.join(get_package_share_directory(gazebo_pkg), 'launch', 'gazebo.launch.py')
    world_path = os.path.join(pkg_share, 'worlds', world_file)
    urdf_file = os.path.join(pkg_share, 'urdf', 'hexa.urdf.xacro')  # Make sure hexa.urdf.xacro exists
    
    robot_description = ParameterValue(
        Command(['xacro ', urdf_file]),
        value_type=str
    )

    initial_positions_file = PathJoinSubstitution(
        [FindPackageShare("hexa"), "config", "hexapod_initial_positions.yaml"]
    )
    
    return LaunchDescription([
        # Launch Gazebo
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(gazebo_launch_file),
            launch_arguments={'world': world_path}.items(),
        ),

        # Spawn Hexapod Model in Gazebo
        Node(
            package="gazebo_ros",
            executable="spawn_entity.py",
            arguments=["-entity", "hexa", "-file", urdf_file],
            output="screen",
        ),

        # Robot State Publisher (Publishes URDF transforms)
        Node(
            package="robot_state_publisher",
            executable="robot_state_publisher",
            parameters=[{'robot_description': robot_description}],
            output="screen",
        ),

        # Controller Manager
        Node(
            package="controller_manager",
            executable="ros2_control_node",
            parameters=[{'robot_description': robot_description}],
            output="screen",
        ),

        # Joint State Broadcaster
        Node(
            package="controller_manager",
            executable="spawner",
            arguments=["joint_state_broadcaster"],
            output="screen",
        ),

        # Joint Trajectory Controller
        Node(
            package="controller_manager",
            executable="spawner",
            arguments=["joint_trajectory_controller"],
            output="screen",
        ),

        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            parameters=[initial_positions_file],
            output='screen'
        ),
    ])
