from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch_ros.actions import Node
from launch.substitutions import LaunchConfiguration, Command
from launch_ros.parameter_descriptions import ParameterValue
import os
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    hexa_description = get_package_share_directory('hexa')
    urdf_file = os.path.join(hexa_description, 'urdf', 'hexa.urdf.xacro')
    controllers_yaml = os.path.join(hexa_description, 'config', 'hexa_controllers.yaml')

    return LaunchDescription([
        DeclareLaunchArgument(
            'use_sim_time',
            default_value='true',
            description='Use simulation (Gazebo) clock if true'),

        DeclareLaunchArgument(
            'robot_description',
            default_value=Command(['xacro ', urdf_file]),
            description='URDF robot description'),

        # Load robot description
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            parameters=[{'robot_description': ParameterValue(Command(['xacro ', urdf_file]), value_type=str)}],
            output='screen'),

        # Controller Manager
        Node(
            package='controller_manager',
            executable='ros2_control_node',
            parameters=[controllers_yaml, {'use_sim_time': LaunchConfiguration('use_sim_time')}],
            output='screen'),

        # Spawning controllers
        Node(
            package='controller_manager',
            executable='spawner',
            arguments=['joint_state_broadcaster', '--controller-manager', '/controller_manager'],
            output='screen'),

        Node(
            package='controller_manager',
            executable='spawner',
            arguments=['joint_trajectory_controller', '--controller-manager', '/controller_manager'],
            output='screen'),
    ])
